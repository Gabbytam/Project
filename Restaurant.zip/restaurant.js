function validateItems(){
  var name= document.forms["contactUs"]["name"].value;
  var email= document.forms["contactUs"]["email"].value;
  var number= document.forms["contactUs"]["number"].value;
  var inquiry= document.forms["contactUs"]["inquiry"].value;
  var info= document.forms["contactUs"]["info"].value;
  var visit= document.forms["contactUs"]["visit"].value;
  var contact=document.forms["contactUs"]["contact"].value;
  if(name & email & number & info !=""){
alert("Information is valid. Thank you!");
}
}
